
if [ `whoami` == "root" ]; then
    echo "root is not allowed"
    exit 1
fi

