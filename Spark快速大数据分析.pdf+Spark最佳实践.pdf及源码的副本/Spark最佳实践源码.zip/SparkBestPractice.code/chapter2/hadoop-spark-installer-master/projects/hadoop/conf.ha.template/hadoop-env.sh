
export JAVA_HOME=/usr/java/latest
export HADOOP_PREFIX=
export HADOOP_LOG_DIR=

